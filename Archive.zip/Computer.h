#ifndef COMPUTER_H
#define COMPUTER_H

#include <random>
#include <ctime>
#include "User.h"
#include "ttt.h"

class Computer : public User, public TicTacToe {
public:
	Computer() {};
	~Computer() {};

	int getChoice() {
		int choice = 0;
		int c = 1;
		int arr[9] = { 0 };

		for (int i = 0; i < 9; i++) {
			arr[i] = getArr(i);
		}
		
		while (arr[c] != 0) {
			c = rand() % 3;
		}
		setArr(2, c);
	}
};

#endif
