#include "ttt.h"
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <iostream>
#include <time.h>
using namespace sf;
const int max = 9;
Music music;
sf::RenderWindow window(sf::VideoMode(1400, 725), "Tic Tac Toe!");

Event event;
Font font;

Texture back, xs, os;
Sprite board, x, o;

int main() {
	window.setFramerateLimit(30);
	back.loadFromFile("board.png");
	board.setTexture(back);

	if (!music.openFromFile("Washington_State__WSU_Fight_Song.ogg")) {
		std::cout << "error";
	}

	music.play();

	sf::Text text;
	text.setFont(font);
	text.setString("~~~~ Welcome to Tic Tac Toe! ~~~~ \n\n\n");
	text.setCharacterSize(50);
	text.setFillColor(sf::Color(200, 0, 60));
	text.setStyle(sf::Text::Bold | sf::Text::Underlined);

	//player one and player two
	sf::Text players;
	players.setFont(font);
	players.setString("\n\nPlayer 1 will be X's (Cougs) \nPlayer 2 will be O's (Huskies)\n\nThe goal is to get 3 of your shapes in a row, diagonally, vertically, or horizontally.\nThe letters qwe asd zxc will represent the rows and columns of the board\n");

	players.setCharacterSize(30);
	players.setFillColor(sf::Color(100, 0, 200));
	window.setFramerateLimit(30);

	//Press enter to continue string
	sf::Text enter;
	enter.setFont(font);
	enter.setString("\n\n\n\n\nPress enter to continue...\n");
	enter.setCharacterSize(40);
	enter.setFillColor(sf::Color::Black);


	int count = 0;
	while (window.isOpen())
	{
		if (count == 0) {
			window.draw(text);
			window.draw(players);
			window.draw(enter);
			system("pause");
			if (sf::Keyboard::isKeyPressed(sf::Keyboard::Enter)) {
				window.display();
				window.clear(sf::Color::White);
			}
		}

		count++;

		window.clear(sf::Color::White);

		sf::Event event;
		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
				window.close();
		}

		window.clear();
		window.draw(board);
		window.display();
	}

	return 0;
}



//sf::VideoMode(1024, 1024), "Tic Tac Toe"