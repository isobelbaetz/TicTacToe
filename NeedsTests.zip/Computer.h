#ifndef COMPUTER_H
#define COMPUTER_H

#include <random>
#include <ctime>
#include "User.h"
#include "Player.h"

class Computer : public Player {
private:
	const int playerID;
public:
	Computer(int pID) : playerID(pID) {}

	void doMove(int arr[]) {
		int c = 0; 
		do{
				c = rand() % 9;
		} while (arr[c] != 0);
		arr[c] = playerID;
	}
};

#endif
