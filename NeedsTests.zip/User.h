#ifndef USER_H
#define USER_H

#include "Player.h"

class User : public Player {
private:
	const int playerID;

public:

	User(int pID) : playerID(pID){ }

	void doMove(int arr[]) {
		int placed = 0;
		while (placed == 0) {
			if (Keyboard::isKeyPressed(Keyboard::Q) && arr[0] == 0) {
				arr[0] = playerID;
				placed = 1;
			}
			else if (Keyboard::isKeyPressed(Keyboard::W) && arr[1] == 0) {
				arr[1] = playerID;
				placed = 1;

			}
			else if (Keyboard::isKeyPressed(Keyboard::E) && arr[2] == 0) {
				arr[2] = playerID;
				placed = 1;

			}
			if (Keyboard::isKeyPressed(Keyboard::A) && arr[3] == 0) {
				arr[3] = playerID;
				placed = 1;

			}
			if (Keyboard::isKeyPressed(Keyboard::S) && arr[4] == 0) {
				arr[4] = playerID;
				placed = 1;

			}
			if (Keyboard::isKeyPressed(Keyboard::D) && arr[5] == 0) {
				arr[5] = playerID;
				placed = 1;

			}
			if (Keyboard::isKeyPressed(Keyboard::Z) && arr[6] == 0) {
				arr[6] = playerID;
				placed = 1;

			}
			if (Keyboard::isKeyPressed(Keyboard::X) && arr[7] == 0) {
				arr[7] = playerID;
				placed = 1;

			}
			if (Keyboard::isKeyPressed(Keyboard::C) && arr[8] == 0) {
				arr[8] = playerID;
				placed = 1;

			}
		}
	}

};

#endif
