#ifndef COMPUTER_H
#define COMPUTER_H

#include <random>
#include <time.h>
#include "User.h"
#include "ttt.h"

class Computer : public User, public TicTacToe {
public:
	Computer() {};
	~Computer() {};

	int getChoice() {

	}
};

#endif
