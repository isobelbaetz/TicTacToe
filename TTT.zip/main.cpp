#include "ttt.h"
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <iostream>
#include <time.h>


Music music;

Event event;
Font font;

Texture back, xs, os;
Sprite board, x, o;

int main() {
	int p1s = 0;
	int p2s = 0;
	int tie = 0;


	RenderWindow window(sf::VideoMode(1400, 750), "Tic Tac Toe");

	Event event;


	//playing the music and opening the file for tic tac toe
	Music music;
	if (!music.openFromFile("Washington_State__WSU_Fight_Song.ogg")) {
		std::cout << "error";
	}
	//music.play();


	TicTacToe player;

	int gamestate = 0;
	int choice = 0;
	int arr[3][3] = { 0 };
	int win = 0;
	Keyboard::Key currentKey;

	while (window.isOpen()) {
		window.clear(sf::Color::White);	

		if (gamestate == 0) {
			choice = player.playerchoice(window);
			if (choice == 1) {
				//player 2 = new computer
				gamestate = 1;
				
			}
			if (choice == 2) {
				//player 2 = new user
				gamestate = 2;
			}
		}

		//if 2 is pressed
		if (gamestate == 2) {
			window.clear(Color::White);
			player.menuScreen(window, p1s, p2s, tie);
			player.drawBoard(window, arr);
		}
		
			


		while (Keyboard::isKeyPressed(Keyboard::Num2)) {
			currentKey = Keyboard::Num2;
		}
		

		//allows the program to close the text.

		while (window.pollEvent(event))
		{
			if (gamestate == 2) {

				while (win == 0) {
					win = player.gamePlay(window, p1s, p2s, tie, arr);
				}
			}

			if (event.type == sf::Event::Closed)
				window.close();
			window.display();
			if (win == 1)
				p1s++;
			if (win == 2)
				p2s++;
			if (win == 3)
				tie++;
		}
	}


	return 0;


}
