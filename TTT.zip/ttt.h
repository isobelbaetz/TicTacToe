#pragma once
#ifndef TTT_H
#define TTT_H
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <iostream>
using namespace sf;
class TicTacToe {
private:


public:
	//constructor not made yet
	TicTacToe();
	//1 or 2 players
	int playerchoice(RenderWindow& window);
	//drawing the board and takes in the render window
	void drawBoard(RenderWindow& window, int arr[][3]);
	//drawing the circle posx and posy determines where on the board it will lie
	void drawCircle(RenderWindow& window, int posX, int posY);
	//drawing the x posx and posy determine where on the board it will lie
	void drawX(RenderWindow& window, int posX, int posY);
	void menuScreen(RenderWindow& window, int, int, int);
	int gamePlay(RenderWindow& window, int p1, int p2, int tie, int arr[][3]);
	int p1gamePlay(RenderWindow& window, int, int, int, int arr[][3]);
	int p2gamePlay(RenderWindow& window, int, int, int, int arr[][3]);
	int checkWin(int arr[][3]);

};



#endif

