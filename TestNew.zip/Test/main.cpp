#include <SFML/Graphics.hpp>

int main() {
	sf::RenderWindow window(sf::VideoMode(1000, 800), "Tic Tac Toe");

	sf::Event event;
	sf::Font font;
	font.loadFromFile("Summit Attack.ttf");
	//welcome screen with tic tac toe
	sf::Text text;
	text.setFont(font);
	text.setString("Welcome to Tic Tac Toe! \n\n\n");
	text.setCharacterSize(40);
	text.setFillColor(sf::Color(200, 0, 60));
	text.setStyle(sf::Text::Bold | sf::Text::Underlined);
	//player one and player two
	sf::Text players;
	players.setFont(font);
	players.setString("\n\nPlayer 1 will be X's (Cougs) \nPlayer 2 will be O's (Huskies)\n");

	players.setCharacterSize(20);
	players.setFillColor(sf::Color(100, 0, 200));
	window.setFramerateLimit(30);
	//Press enter to continue string
	sf::Text enter;
	enter.setFont(font);
	enter.setString("\n\n\nPress enter to continue...\n");
	enter.setCharacterSize(30);
	enter.setFillColor(sf::Color::Black);

	sf::CircleShape circle(100.f);
	circle.setPointCount(100);
	circle.setFillColor(sf::Color::White);
	circle.setOutlineThickness(10.f);
	circle.setOutlineColor(sf::Color(166, 61, 72));

	circle.setPosition(10, 10);


	while (window.isOpen()) {

		window.clear(sf::Color::White);
		//window.draw(circle);
		window.draw(text);
		window.draw(players);
		window.draw(enter);

		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Enter)) {
			window.display();
			window.clear(sf::Color::White);

		}
		//allows the program to close the text.
		while (window.pollEvent(event))
		{

			if (event.type == sf::Event::Closed)
				window.close();
		}
		window.display();
	}


	return 0;

}
