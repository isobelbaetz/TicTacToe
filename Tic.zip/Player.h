#ifndef PLAYER_H
#define PLAYER_H
#include <SFML/Graphics.hpp>
using namespace sf;

class Player {

public:
	virtual void doMove(int arr[]) = 0;

};

#endif