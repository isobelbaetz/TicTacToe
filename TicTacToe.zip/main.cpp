#include <SFML/Graphics.hpp>

int main() {
	sf::RenderWindow window(sf::VideoMode(1000, 800), "Tic Tac Toe");

	sf::Event event;
	sf::Font font;
	font.loadFromFile("DearSunshine.ttf");
	sf::Text text;
	text.setFont(font);
	text.setString("Player 1 Score: ");
	text.setCharacterSize(15);
	text.setFillColor(sf::Color::White);


	window.setFramerateLimit(30);

	
	sf::CircleShape circle(100.f);
	circle.setPointCount(100);
	circle.setFillColor(sf::Color::White);
	circle.setOutlineThickness(10.f);
	circle.setOutlineColor(sf::Color(166,61,72));
	window.draw(circle);
	circle.setPosition(10, 10);


	while (window.isOpen()) {
		window.clear();
		window.clear(sf::Color::White);
		window.draw(circle);
		window.display();
	}


	return 0;

}