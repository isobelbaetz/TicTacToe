#ifndef COMPUTER_H
#define COMPUTER_H

#include <random>
#include <ctime>
#include "User.h"
#include "ttt.h"

class Computer : public User, public TicTacToe {
public:
	Computer() {};
	~Computer() {};

	int getChoice() {
		int choice = 0;
		int c, d;
		int arr[][] = getArr();
		
		while (arr[c][d] != 0) {
			c = rand() % 3;
			d = rand() % 3;
		}
		setArr(2, c, d);
	}
};

#endif
