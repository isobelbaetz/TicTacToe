#ifndef USER_H
#define USER_H

class User {
protected:

	int score;
public:

	User() { score = 0; };
	~User(){};
	void setScore(int s) { score = s; };
	int getScore(void) { return score; };

};

#endif
