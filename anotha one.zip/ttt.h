#pragma once
#ifndef TTT_H
#define TTT_H
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <iostream>
using namespace sf;
class TicTacToe {
private:
	int arr[9];
public:
	//constructor not made yet
	TicTacToe();
	//destructor
	~TicTacToe() {}
	//set array
	void setArr(int, int, int);
	//get element as a pos
	int* getArr(void);

	//1 or 2 players
	int playerchoice(RenderWindow& window);
	//drawing the board and takes in the render window
	void drawBoard(RenderWindow& window, int arr[]);
	//drawing the circle posx and posy determines where on the board it will lie
	void drawCircle(RenderWindow& window, int posX, int posY);
	//drawing the x posx and posy determine where on the board it will lie
	void drawX(RenderWindow& window, int posX, int posY);
	void menuScreen(RenderWindow& window, int, int, int);
	int gamePlay(RenderWindow& window, int p1, int p2, int tie, int arr[]);
	int p1gamePlay(RenderWindow& window, int, int, int, int arr[]);
	int p2gamePlay(RenderWindow& window, int, int, int, int arr[]);
	int checkWin(int arr[]);

};



#endif

